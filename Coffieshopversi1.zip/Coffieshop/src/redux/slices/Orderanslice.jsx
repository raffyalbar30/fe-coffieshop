import { createSlice } from '@reduxjs/toolkit'
const orderstate = {
    order: [],
}
