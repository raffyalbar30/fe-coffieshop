
import React from 'react';
import Input from '../components/Inputs/Inputs';
import Button from '../components/Buttons/Button';
import { useNavigate } from "react-router-dom"
import { useState } from 'react';
import { useEffect } from 'react';


const Pembayaranpage = () => {
    const [Datauser, setDatauser] = useState(null)
    const Navigatebatal = useNavigate();
    const Handlebatal = () => {
        Navigatebatal("/userpage")
    }

    const Handlechange = (e) => {
        setDatauser({
          ...Datauser,
          [e.target.name]: e.target.value
        })
    }
   const Handlecekout = () => {
        useEffect(()=>{
            localStorage.setItem("order", Datauser)
        }, [Datauser])
   }
  return (

     <>
     <div className='flex justify-center mt-8'>
   <div className='w-[700px] h-auto border border-slate-300 rounded-md '>

       <div className=' mt-8'>
          <img src="/img/logo.png" alt="" className='mx-auto' />
          <div className='flex justify-center'>
          <span>silahkan lengkapi pembelian !!</span>
          </div>
       </div>

       <div className='flex justify-center mt-4'>
          <div className='pl-2 pt-2'>
            <div className='mr-12'>
            <span>Nama Pembeli</span>
            <Input  type="text" name="pembeli" classname={`px-24`}  onChange={Handlechange} ></Input> 
            <span>Alamat</span>
            <Input  type="text" name="nama" classname={`px-24`} onChange={Handlechange} ></Input> 
            <span>No telepon aktive</span>
            <Input  type="text" name="notekpon" classname={`px-24`} onChange={Handlechange} ></Input> 
         
          <div className='flex gap-x-2 mt-4'>
            <div className='w-[250px] border border-slate-400 ml-2 p-2 rounded-md'>
            <span className='text-xl font-semibold'>Playments</span>
             <select name="" id="" className="border border-slate-400 rounded-md float-right p-2">
                <option>Cash</option>
                <option >Qriss</option>
             </select>
            </div>
          </div>
          </div>
          <div className='flex-wrapp ml-24 mt-24 mb-4'>
              <Button onClick={ Handlecekout}>Cek Out</Button>
              <Button onClick={Handlebatal}>Batalkan</Button>
          </div>
          </div>
       </div>

   </div>
   </div>
     </>
  );
}

export default Pembayaranpage;

