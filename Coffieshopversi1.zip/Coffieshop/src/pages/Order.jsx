import React from 'react';
import { useSelector } from 'react-redux';


const order = {
     Nama : "Raffy albar", 
     Alamat : "Bojong girang",
     Pembayaran : "Cash",
     No_telpon : "085694175143"
}
const Order = () => {
    const { cart } = useSelector(all => all.cart);

    return (
        <>
     <div className='flex justify-center mt-8'>
   <div className='w-[700px] h-auto border border-slate-300 rounded-md '>

       <div className=' mt-8'>
          <img src="/img/logo.png" alt="" className='mx-auto' />
          <div className='flex justify-center'>
             <div className='flex-wrap'>
                  <div className='mt-4'>
                          <p>Nama Pembeli : {order.Nama}</p>
                          <p>Alamat : {order.Alamat}</p>
                          <p>Pembayaran : {order.Pembayaran}</p>
                          <p>No Telepon : {order.No_telpon}</p>
                        {cart?.map((items)=>{
                              <img src={items.img} />
                        })}
                  </div>
             </div>
          </div>
       </div>


   </div>
   </div>
        </>
    );
}

export default Order;
