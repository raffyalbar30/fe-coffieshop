import React from 'react'
import Benner from '../components/Corusellbener/Benner'

function Beneruser() {
  return (
    <Benner></Benner>
  )
}

export default Beneruser