import React from 'react';

const Cartfalse = () => {
    return (
        <div>
            <p>Carts gak ada</p>
        </div>
    );
}

export default Cartfalse;
